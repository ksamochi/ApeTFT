| Supported Targets | ESP32-C5 | ESP32-H2 | ESP32-H4 | ESP32-P4 |
| ----------------- | -------- | -------- | -------- | -------- |

This test app is used to test LCDs with intel 8080 interface.
