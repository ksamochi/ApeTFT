# How to generate the YUV image from the PNG image

```bash
ffmpeg -i hello.png -pix_fmt uyvy422 hello.yuv
```
