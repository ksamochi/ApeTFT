| Supported Targets | ESP32-P4 | ESP32-S3 |
| ----------------- | -------- | -------- |

This test app is used to test RGB565 interfaced LCDs.
