| Supported Targets | ESP32-P4 |
| ----------------- | -------- |

This test app is used to test MIPI DSI interfaced LCDs.
