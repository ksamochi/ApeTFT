
def initEvent(event_struct):
    return


def OpnTouch(event_struct):
    return


def TripClickD(event_struct):
    return


def TripLongD(event_struct):
    return


def LfwLongD(event_struct):
    return


def TripClickL(event_struct):
    return


def TripLongL(event_struct):
    return


def LfwLongL(event_struct):
    return


def PlsSetRst(event_struct):
    return


def PlsSetCalibSp(event_struct):
    return


def PlsSetCalibOdo(event_struct):
    return

